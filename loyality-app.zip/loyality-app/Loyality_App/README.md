# Loyality_App
 Loyality_App using Php
