

<html>
    <head>
        <meta charset="UTF-8">
        <title>SignUp</title>
    </head>
    <body>
        <form>
            <label>First Name</label>
            <input type="text" name="First_Name"required >
 <label>Last Name</label>
            <input type="text" name="Last_Name"required >
             <label>Email</label>
            <input type="email" name="Email"required >
             <label>Password</label>
            <input type="password" name="Password"required >
             <label>Birthday</label>
            <input type="date" name="Birthday"required >
        </form>
    </body>
</html>
